import pyodbc

try:
    conexion = pyodbc.connect(
        'DRIVER={ODBC Driver 18 for SQL Server};'
        'SERVER=localhost;'
        'DATABASE=BibliotecaUniversitaria;'
        'Trusted_Connection=yes;'
        'TrustServerCertificate=yes;'
    )
    print('Conectada')
    print('---------------')
except pyodbc.Error as e:
    print('No se pudo conectar')
    print(e)


cursor = conexion.cursor()

def insertar_prestamo(id_estudiante, id_ejemplar):
    cursor.execute("EXEC InsertarPrestamo ?, ?", (id_estudiante, id_ejemplar))
    conexion.commit()
    print('Prestamo insertado Exitosamente')
    print('---------------')
    

def consultar_libros(id_libro=None, titulo=None, ISBN=None, cantidad_paginas=None, editorial=None):
    try:
        cursor.execute("EXEC ConsultarLibros ?, ?, ?, ?, ?", (id_libro, titulo, ISBN, cantidad_paginas, editorial))
        resultados = cursor.fetchall()
        
        if resultados:
            print("Resultados encontrados:")
            for libro in resultados:
                print(libro)  
        else:
            print("No se encontraron libros con los criterios proporcionados.")
            
        return resultados
    
    except pyodbc.Error as e:
        print("Error al consultar libros:", e)
        return None

def actualizar_autor(id_autor, nombre, nacionalidad, fecha_nacimiento):
    cursor.execute("EXEC ActualizarAutor ?, ?, ?, ?", (id_autor, nombre, nacionalidad, fecha_nacimiento))
    conexion.commit()
    print('Libro actualizado Exitosamente')
    print('---------------')

def borrar_estudiante(id_estudiante):
    cursor.execute("EXEC BorrarEstudiante ?", (id_estudiante,))
    conexion.commit()
    print('Estudiante Eliminado Exitosamente')
    print('---------------')

def cerrar_conexion():
    cursor.close()
    conexion.close()
    print('Conexion Cerrada')
    print('---------------')

def menu():
    opcion = 1
    print('Bienvenido al Sistema de Biblioteca - Dylan Solano Pereira C37637')
    while(opcion > 0 and opcion < 5):
        opcion = int(input('Digite #1 para Insertar un prestamo \nDigite #2 para Consultar un libro'
                   + '\nDigite #3 para Actualizar un Autor \nDigite #4 para Borrar un Estudiante'
                   + '\nDigite cualquier otro numero para salir\n'))
        if(opcion == 1):
            idEstudiante = input('Ingrese en id del estudiante: ')
            idEjemplar = input('Ingrese en id del ejemplar: ')
            insertar_prestamo(idEstudiante,idEjemplar)
        
        if(opcion == 2):
            titulo = input('Ingrese el titulo del libro: ').strip()
            print(consultar_libros(titulo=titulo))

        if(opcion == 3):
            idAutor = input('Ingrese en id del Autor: ')
            nombre = input('Ingrese eel nombre del autor: ')
            nacionalidad = input('Ingrese la nacionalidad del autor: ')
            fecha = input('Ingrese la fecha de nacimiento del autor: ')
            actualizar_autor(idAutor,nombre,nacionalidad,fecha)
        
        if(opcion == 4):
            idEstudiante = input('Ingrese el id del estudiante: ')
            borrar_estudiante(idEstudiante)

    

menu()
cerrar_conexion()
print("Fin del programa")