--CREATE DATABASE BibliotecaUniversitaria;

USE BibliotecaUniversitaria;

-- Tabla Autor
CREATE TABLE Autor (
    idAutor INT PRIMARY KEY IDENTITY(1,1),
    nombre NVARCHAR(100) NOT NULL,
    nacionalidad NVARCHAR(50),
    fechaNacimiento DATE
);

-- Tabla Libro
CREATE TABLE Libro (
    idLibro INT PRIMARY KEY IDENTITY(1,1),
    titulo NVARCHAR(150) NOT NULL,
    ISBN NVARCHAR(13),
    cantidadPaginas INT,
    editorial NVARCHAR(100),
    idAutor INT,
    FOREIGN KEY (idAutor) REFERENCES Autor(idAutor)
);

-- Tabla Ejemplar
CREATE TABLE Ejemplar (
    idEjemplar INT PRIMARY KEY IDENTITY(1,1),
    idLibro INT,
    estado NVARCHAR(50) NOT NULL, -- Ej: Disponible, Prestado
    FOREIGN KEY (idLibro) REFERENCES Libro(idLibro)
);

-- Tabla Estudiante
CREATE TABLE Estudiante (
    idEstudiante INT PRIMARY KEY IDENTITY(1,1),
    nombre NVARCHAR(100) NOT NULL,
    matricula NVARCHAR(20) NOT NULL UNIQUE,
    carrera NVARCHAR(100),
    telefono NVARCHAR(15),
    correo NVARCHAR(100)
);

-- Tabla Prestamo
CREATE TABLE Prestamo (
    idPrestamo INT PRIMARY KEY IDENTITY(1,1),
    idEstudiante INT,
    idEjemplar INT,
    fechaPrestamo DATE NOT NULL DEFAULT GETDATE(),
    fechaDevolucion DATE,
    FOREIGN KEY (idEstudiante) REFERENCES Estudiante(idEstudiante),
    FOREIGN KEY (idEjemplar) REFERENCES Ejemplar(idEjemplar)
);

--Procedimiento Almacenado De Insertar Prestamos de Libros 
CREATE PROCEDURE InsertarPrestamo
    @idEstudiante INT,
    @idEjemplar INT
AS
BEGIN
    INSERT INTO Prestamo (idEstudiante, idEjemplar)
    VALUES (@idEstudiante, @idEjemplar);
END;
GO

-- Procedimiento Almacenado Para Consultar Libros 
CREATE PROCEDURE ConsultarLibros
    @idLibro INT = NULL,
    @titulo NVARCHAR(150) = NULL,
    @ISBN NVARCHAR(13) = NULL,
    @cantidadPaginas INT = NULL,
    @editorial NVARCHAR(100) = NULL
AS
BEGIN
    SELECT * FROM Libro
    WHERE 
        (@idLibro IS NULL OR idLibro = @idLibro) AND
        (@titulo IS NULL OR titulo LIKE '%' + @titulo + '%') AND
        (@ISBN IS NULL OR ISBN = @ISBN) AND
        (@cantidadPaginas IS NULL OR cantidadPaginas = @cantidadPaginas) AND
        (@editorial IS NULL OR editorial LIKE '%' + @editorial + '%');
END;
GO

--Procedimiento Almacenado Para Actualizar Autores 
CREATE PROCEDURE ActualizarAutor
    @idAutor INT,
    @nombre NVARCHAR(100),
    @nacionalidad NVARCHAR(50),
    @fechaNacimiento DATE
AS
BEGIN
    UPDATE Autor
    SET nombre = @nombre,
        nacionalidad = @nacionalidad,
        fechaNacimiento = @fechaNacimiento
    WHERE idAutor = @idAutor;
END;
GO

--Procedimiento Almacenado Para Eliminar Estudiantes
CREATE PROCEDURE BorrarEstudiante
    @idEstudiante INT
AS
BEGIN
    DELETE FROM Estudiante
    WHERE idEstudiante = @idEstudiante;
END;

INSERT INTO Autor (nombre, nacionalidad, fechaNacimiento) VALUES ('Gabriel Garc�a M�rquez', 'Colombiana', '1927-03-06');
INSERT INTO Autor (nombre, nacionalidad, fechaNacimiento) VALUES ('Julio Cort�zar', 'Argentina', '1914-08-26');
INSERT INTO Autor (nombre, nacionalidad, fechaNacimiento) VALUES ('Isabel Allende', 'Chilena', '1942-08-02');
INSERT INTO Autor (nombre, nacionalidad, fechaNacimiento) VALUES ('Mario Vargas Llosa', 'Peruana', '1936-03-28');
INSERT INTO Autor (nombre, nacionalidad, fechaNacimiento) VALUES ('Jorge Luis Borges', 'Argentina', '1899-08-24');

INSERT INTO Libro (titulo, ISBN, cantidadPaginas, editorial, idAutor) VALUES ('Cien A�os de Soledad', '9780307474728', 417, 'Sudamericana', 1);
INSERT INTO Libro (titulo, ISBN, cantidadPaginas, editorial, idAutor) VALUES ('Rayuela', '9788437604947', 735, 'Punto de Lectura', 2);
INSERT INTO Libro (titulo, ISBN, cantidadPaginas, editorial, idAutor) VALUES ('La Casa de los Esp�ritus', '9788497592017', 490, 'Plaza & Jan�s', 3);
INSERT INTO Libro (titulo, ISBN, cantidadPaginas, editorial, idAutor) VALUES ('La Ciudad y los Perros', '9788420434710', 384, 'Alfaguara', 4);
INSERT INTO Libro (titulo, ISBN, cantidadPaginas, editorial, idAutor) VALUES ('Ficciones', '9788426400603', 256, 'Debolsillo', 5);

INSERT INTO Ejemplar (idLibro, estado) VALUES (1, 'Disponible');
INSERT INTO Ejemplar (idLibro, estado) VALUES (2, 'Prestado');
INSERT INTO Ejemplar (idLibro, estado) VALUES (3, 'Disponible');
INSERT INTO Ejemplar (idLibro, estado) VALUES (4, 'Prestado');
INSERT INTO Ejemplar (idLibro, estado) VALUES (5, 'Disponible');

INSERT INTO Estudiante (nombre, matricula, carrera, telefono, correo) VALUES ('Carlos P�rez', '2023001', 'Ingenier�a de Sistemas', '555123456', 'carlos.perez@universidad.edu');
INSERT INTO Estudiante (nombre, matricula, carrera, telefono, correo) VALUES ('Mar�a G�mez', '2023002', 'Medicina', '555123457', 'maria.gomez@universidad.edu');
INSERT INTO Estudiante (nombre, matricula, carrera, telefono, correo) VALUES ('Juan L�pez', '2023003', 'Derecho', '555123458', 'juan.lopez@universidad.edu');
INSERT INTO Estudiante (nombre, matricula, carrera, telefono, correo) VALUES ('Ana Ram�rez', '2023004', 'Econom�a', '555123459', 'ana.ramirez@universidad.edu');
INSERT INTO Estudiante (nombre, matricula, carrera, telefono, correo) VALUES ('Laura Mart�nez', '2023005', 'Psicolog�a', '555123460', 'laura.martinez@universidad.edu');
INSERT INTO Estudiante (nombre, matricula, carrera, telefono, correo) VALUES ('Mario Mart�nez', '2823005', 'Psicolog�a', '545123460', 'mario.martinez@universidad.edu');

INSERT INTO Prestamo (idEstudiante, idEjemplar, fechaPrestamo, fechaDevolucion) VALUES (1, 1, '2024-01-10', '2024-01-20');
INSERT INTO Prestamo (idEstudiante, idEjemplar, fechaPrestamo, fechaDevolucion) VALUES (2, 2, '2024-01-15', '2024-01-25');
INSERT INTO Prestamo (idEstudiante, idEjemplar, fechaPrestamo, fechaDevolucion) VALUES (3, 3, '2024-01-20', '2024-01-30');
INSERT INTO Prestamo (idEstudiante, idEjemplar, fechaPrestamo, fechaDevolucion) VALUES (4, 4, '2024-01-25', '2024-02-05');
INSERT INTO Prestamo (idEstudiante, idEjemplar, fechaPrestamo, fechaDevolucion) VALUES (5, 5, '2024-01-30', '2024-02-10');

--SELECT * FROM AUTOR;
--SELECT * FROM Estudiante;
--SELECT * FROM Prestamo;
--SELECT * FROM EJEMPLAR;
--SELECT * FROM LIBRO;